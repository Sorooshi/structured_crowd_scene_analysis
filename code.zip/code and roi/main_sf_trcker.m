% Soroosh Shalileh Crowd Scene Analysis 
setup ;
% Training cofiguration
targetClass = 1 ;   % 'Biker' 
% targetClass = 2 ; % 'Skater' 
% targetClass = 3 ; % 'Aped' 
% targetClass = 4    % 'Cart' ;




numHardNegativeMiningIterations = 9 ;
% schedule = [100 200 300 500 750 400 500 ] ; [40: 200 :1192] 
schedule = [40 40 120 200 500 800 1040 1040 1192] ; % Akharin
% schedule = [100 200 250 350 350];

% Scale space configuration
hogCellSize = 8 ;
minScale = -1 ;
maxScale = 3 ;
numOctaveSubdivisions = 3 ;
scales = 2.^linspace(...
  minScale,...
  maxScale,...
  numOctaveSubdivisions*(maxScale-minScale+1)) ;

%%  
% Load data
trainImages = {} ;
trainBoxes = [] ;
trainBoxPatches = {} ;
trainBoxImages = {} ;
trainBoxLabels = [] ;

% Compute HOG features of examples (see Step 1.2)
trainBoxHog = {} ;
names = dir('data/Positive_biker_double/*.jpg') ;
names = fullfile('data', 'Positive_biker_double', {names.name}) ;
for i=1:numel(names)
  im = imread(names{i}) ;
  im = imresize(im, [64 64]) ;
%   trainBoxes(:,i) = [0.5 ; 0.5 ; 64.5 ; 64.5] ;
  trainBoxPatches{i} = im2single(im) ;
%   trainBoxImages{i} = names{i} ;
  trainBoxLabels(i) = 1 ;
end

trainBoxPatches = cat(4, trainBoxPatches{:}) ;

% Compute HOG features of examples (see Step 1.2)
trainBoxHog = {} ;
for i = 1:size(trainBoxPatches,4)
  trainBoxHog{i} = vl_hog(trainBoxPatches(:,:,:,i), hogCellSize) ;
end
trainBoxHog = cat(4, trainBoxHog{:}) ;
modelWidth = size(trainBoxHog,2) ;
modelHeight = size(trainBoxHog,1) ;

% -------------------------------------------------------------------------
% Train with hard negative mining for each class
% -------------------------------------------------------------------------

% Initial positive and negative data
pos = trainBoxHog(:,:,:,ismember(trainBoxLabels,targetClass)) ;
neg = zeros(size(pos,1),size(pos,2),size(pos,3),0) ;
% -------------------------------------------------------------------------
% Loading train data :
% Biker Data :
addpath('C:\Users\Soroosh\Documents\MATLAB\SorooshThesis\code\SlidingWin_Trckr\data\Positive_biker')
load('UCSD1_Biker.mat')
trainImages     = UCSD1_Biker.Images(1:2:end) ;
trainBoxes      = UCSD1_Biker.BoxImages(:,1:2:end) ;
trainBoxImages  = UCSD1_Biker.Images(1:2:end) ;
% hard_minning = true ;
% -------------------------------------------------------------------------
%%
for t=1:numHardNegativeMiningIterations
  numPos = size(pos,4) ;
  numNeg = size(neg,4) ;
  C = 1 ;
  lambda = 1 / (C * (numPos + numNeg)) ;

  fprintf('Hard negative mining iteration %d: pos %d, neg %d\n', ...
    t, numPos, numNeg) ;

  % Train an SVM model (see Step 2.2)
  x = cat(4, pos, neg) ;
  x = reshape(x, [], numPos + numNeg) ;
  y = [ones(1, size(pos,4)) -ones(1, size(neg,4))] ;
  w = vl_svmtrain(x,y,lambda,'epsilon',0.01,'verbose') ;
  w = single(reshape(w, modelHeight, modelWidth, [])) ;

  % Plot model
  figure(1) ; clf ;
  imagesc(vl_hog('render', w)) ;
  colormap gray ; axis equal ;
  title(sprintf('SVM HOG model (retraining ieration %d)',t)) ;

  % Evaluate on training data and mine hard negatives
  figure(2) ; set(gcf, 'name', sprintf('Retraining iteration %d',t)) ;
  [matches, moreNeg] = ...
    my_evaluateModel(...
    vl_colsubset(trainImages', schedule(t), 'beginning'), ...
    trainBoxes, trainBoxImages, ...
    w, hogCellSize, scales ) ; %hard_minning

  % Add negatives
  neg = cat(4, neg, moreNeg) ;

  % Remove negative duplicates
  z = reshape(neg, [], size(neg,4)) ;
  [~,keep] = unique(z','stable','rows') ;
  neg = neg(:,:,:,keep) ;
end

% -------------------------------------------------------------------------
% Step 4.2: Evaluate the model on the test data
% -------------------------------------------------------------------------
%% 
figure(3) ; clf ;
hard_minning =   false;
testImages     = UCSD1_Biker.Images(2:3:end) ;
testBoxes      = UCSD1_Biker.BoxImages(:,2:3:end) ;
testBoxImages  = UCSD1_Biker.Images(2:3:end) ;

[matches_Biker_without_tracker] = my_evaluateModel(testImages, ...
   testBoxes, testBoxImages , ...
    w, hogCellSize, scales) ;

% % figure; vl_pr([test_1.labels], [test_1.scores])
% % figure; vl_pr([test_2.labels], [test_2.scores])
% % figure; vl_pr([test.labels], [test.scores])