% Soroosh Shalileh Crowd Scene Analysis
setup ;
% Training cofiguration
targetClass = 1 ;   

numHardNegativeMiningIterations = 7 ;
% schedule =  [100 200 200 400 400 700 800 ] ; Biker
schedule = [50 50 100 350 350 460 460 ] ;
% Scale space configuration
hogCellSize = 4 ;
minScale = -1 ;
maxScale = 3 ;
numOctaveSubdivisions = 3 ;
scales = 2.^linspace(...
    minScale,...
    maxScale,...
    numOctaveSubdivisions*(maxScale-minScale+1)) ;

%% Load data
trainImages = {} ;
trainBoxes = [] ;
trainBoxPatches = {} ;
trainBoxImages = {} ;
trainBoxLabels = [] ;

% Compute HOG features of examples (see Step 1.2)
trainBoxHog = {} ;
% Biker :
% names = dir('data/Positive_biker_modified/*.jpg') ;
% names = fullfile('data', 'Positive_biker_modified', {names.name}) ;
%**************************************************************************
% Cart :
% % names = dir('data/Positives_cart_modified/*.jpg') ;
% % names = fullfile('data', 'Positives_cart_modified', {names.name}) ;
%**************************************************************************
% Abnormal Peds :
names = dir('data/Positives_aped_modified/*.jpg') ;
names = fullfile('data', 'Positives_aped_modified', {names.name}) ;
%**************************************************************************
% Skater :
% % % % names = dir('data/Positives_skater_modified/*.jpg') ;
% % % % names = fullfile('data', 'Positives_skater_modified', {names.name}) ;
%**************************************************************************
% Non Cart Abnormality :
% % % % % names = dir('data/mixed_class/*.jpg') ;
% % % % % names = fullfile('data', 'mixed_class', {names.name}) ;

for i=1:numel(names)
    im = imread(names{i}) ;
    im = imresize(im, [48 48]) ;
    %   trainBoxes(:,i) = [0.5 ; 0.5 ; 64.5 ; 64.5] ;
    trainBoxPatches{i} = im2single(im) ;
    %   trainBoxImages{i} = names{i} ;
    trainBoxLabels(i) = 1 ;
end

trainBoxPatches = cat(4, trainBoxPatches{:}) ;

% Compute HOG features of examples (see Step 1.2)
trainBoxHog = {} ;
for i = 1:size(trainBoxPatches,4)
    trainBoxHog{i} = vl_hog(trainBoxPatches(:,:,:,i), hogCellSize) ;
end
trainBoxHog = cat(4, trainBoxHog{:}) ;
modelWidth = size(trainBoxHog,2) ;
modelHeight = size(trainBoxHog,1) ;

% -------------------------------------------------------------------------
% Train with hard negative mining for each class
% -------------------------------------------------------------------------

% Initial positive and negative data
pos = trainBoxHog(:,:,:,ismember(trainBoxLabels,targetClass)) ;
neg = zeros(size(pos,1),size(pos,2),size(pos,3),0) ;
% -------------------------------------------------------------------------
% Loading train data :
% Biker Data : (1:2:end) (:,1:2:end)
% addpath('C:\Users\Soroosh\Documents\MATLAB\SorooshThesis\code\SlidingWin_Trckr\data\Positive_biker_modified')
% load('UCSD1_Biker.mat')
% trainImages     = UCSD1_Biker.TotalImages2read ;
% trainBoxes      = UCSD1_Biker.BoxImages ;
% trainBoxImages  = UCSD1_Biker.Images ;
%**************************************************************************
% Cart Data :
% % addpath('C:\Users\Soroosh\Documents\MATLAB\SorooshThesis\code\SlidingWin_Trckr\data\Positives_cart_modified')
% % load('UCSD1_Aped.mat')
% % trainImages     = UCSD1_Cart.TotalImages2read  ;
% % trainBoxes      = UCSD1_Cart.BoxImages(:,1:2:end) ;
% % trainBoxImages  = UCSD1_Cart.Images(1:2:end) ;
%**************************************************************************
% Abnormal Peds Data :
addpath('C:\Users\Soroosh\Documents\MATLAB\SorooshThesis\code\SlidingWin_Trckr\data\Positives_aped_modified')
load('UCSD1_Aped.mat')
% trainImages   = UCSD1_Aped.TotalImages2read  ;
trainImages     = UCSD1_Aped.TotalImages2read(Train(:,k)) ; 
trainBoxes      = UCSD1_Aped.BoxImages ;
trainBoxImages  = UCSD1_Aped.Images ;
%**************************************************************************
% Skater Data :
% % % % addpath('C:\Users\Soroosh\Documents\MATLAB\SorooshThesis\code\SlidingWin_Trckr\data\Positives_skater_modified')
% % % % load('UCSD1_Skater.mat')
% % % % trainImages     = UCSD1_Skater.TotalImages2read  ;
% % % % trainBoxes      = UCSD1_Skater.BoxImages(:,1:2:end) ;
% % % % trainBoxImages  = UCSD1_Skater.Images(1:2:end) ;
%**************************************************************************
% Non Cart Abnormality Data :
% % % % % addpath('C:\Users\Soroosh\Documents\MATLAB\SorooshThesis\code\SlidingWin_Trckr\data\mixed_class')
% % % % % load('UCSD1_NonCart.mat')
% % % % % trainImages     = UCSD1_NonCart.TotalImages2read ;
% % % % % trainBoxes      = UCSD1_NonCart.BoxImages.Total ;
% % % % % trainBoxImages  = UCSD1_NonCart.Images.Total ;
%% K fold Cross validation 

%% Hard Mining and training step :
for t=1:numHardNegativeMiningIterations
    numPos = size(pos,4) ;
    numNeg = size(neg,4) ;
    C = 1 ;
    lambda = 1 / (C * (numPos + numNeg)) ;
    
    fprintf('Hard negative mining iteration %d: pos %d, neg %d\n', ...
        t, numPos, numNeg) ;
    
    % Train an SVM model (see Step 2.2)
    x = cat(4, pos, neg) ;
    x = reshape(x, [], numPos + numNeg) ;
    y = [ones(1, size(pos,4)) -ones(1, size(neg,4))] ;
    w = vl_svmtrain(x,y,lambda,'epsilon',0.01,'verbose') ;
    w = single(reshape(w, modelHeight, modelWidth, [])) ;
    
    % Plot model
    figure(1) ; clf ;
    imagesc(vl_hog('render', w)) ;
    colormap gray ; axis equal ;
    title(sprintf('SVM HOG model (retraining ieration %d)',t)) ;
    
    % Evaluate on training data and mine hard negatives
    figure(2) ; set(gcf, 'name', sprintf('Retraining iteration %d',t)) ;
    [matches, moreNeg] = ...
        evaluateModel(...
        vl_colsubset(trainImages', schedule(t), 'beginning'), ...
        trainBoxes, trainBoxImages, ...
        w, hogCellSize, scales ) ; %hard_minning
    
    % Add negatives
    neg = cat(4, neg, moreNeg) ;
    
    % Remove negative duplicates
    z = reshape(neg, [], size(neg,4)) ;
    [~,keep] = unique(z','stable','rows') ;
    neg = neg(:,:,:,keep) ;
end

%% Evaluation Step :
% Biker : (2:3:end) (:,2:3:end) 
% testImages     = UCSD1_Biker.TotalImages2read(2:3:end) ;
% testBoxes      = UCSD1_Biker.BoxImages  ;
% testBoxImages  = UCSD1_Biker.Images ;
% [matches_Biker_with_tracker] = evaluateModel(testImages, ...
%     testBoxes, testBoxImages , ...
%     w, hogCellSize, scales) ;
%**************************************************************************
% % % Cart :
% % testImages     = UCSD1_Cart.TotalImages2read  ;
% % testBoxes      = UCSD1_Cart.BoxImages ;
% % testBoxImages  = UCSD1_Cart.Images;
% % [matches_Cart_without_tracker] = evaluateModel(testImages, ...
% %     testBoxes, testBoxImages , ...  
% %     w, hogCellSize, scales) ;
%**************************************************************************
% Abnormal Peds :
% testImages     = UCSD1_Aped.TotalImages2read(2:4:end) ;
testImages     = datasample(UCSD1_Aped.TotalImages2read,199);
testBoxes      = UCSD1_Aped.BoxImages ;
testBoxImages  = UCSD1_Aped.Images ;
[matches_Aped_without_tracker] = evaluateModel(testImages, ...
    testBoxes, testBoxImages , ...  
    w, hogCellSize, scales) ;

%**************************************************************************
% Skater :
% % % % testImages     = UCSD1_Skater.TotalImages2read ;
% % % % testBoxes      = UCSD1_Skater.BoxImages ;
% % % % testBoxImages  = UCSD1_Skater.Images ;
% % % % [matches_Cart_without_tracker] = evaluateModel(testImages, ...
% % % %     testBoxes, testBoxImages , ...  
% % % %     w, hogCellSize, scales) ;
%**************************************************************************
% Non Cart Abnormality Detection :
% testImages     = UCSD1_NonCart.TotalImages2read ;
% testBoxes      = UCSD1_NonCart.BoxImages.Total ;
% testBoxImages  = UCSD1_NonCart.Images.Total ;
% [matches_noCart_without_tracker] = evaluateModel(testImages, ...
%     testBoxes, testBoxImages , ...  
%     w, hogCellSize, scales) ;
%**************************************************************************
% % figure; vl_pr([test_1.labels], [test_1.scores])
% % figure; vl_pr([test_2.labels], [test_2.scores])
% % figure; vl_pr([test.labels], [test.scores])