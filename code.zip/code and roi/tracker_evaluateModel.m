function [matches, negs,storages_win] = tracker_evaluateModel(...
    testImages, testBoxes, testBoxImages, w, hogCellSize, scales)

clear matches ;
negs = {} ;
storages_win = {};
% load('storages_trckr.mat')
for i=1:numel(testImages)
    if i < numel(testImages)-2
        % Detect on test image
        im = imread(testImages{i}) ;
        im = im2single(im) ;
        [prim_detections, prim_scores, hog] = detect(im, w, hogCellSize, scales) ;
        
        % Non-maxima suppression
        keep = boxsuppress(prim_detections, prim_scores, 0.5) ;
        keep = find(keep) ;
        
        keep = vl_colsubset(keep, 3, 'beginning') ;
        prim_detections = prim_detections(:, keep) ;
        prim_scores = prim_scores(keep) ;
        
        %******************************************************************
        
        cur_img = im ;
        fol_img = imageSet(testImages(i+1)) ;%:1:i+2
        %**
        
%         if mod(i,3)==0
%             idx = find(strcmp(testImages{i},testBoxImages)) ;
%             (testBoxes(:,idx)) ;
%             init = ceil(prim_detections);
%             init = [init ,ceil(testBoxes(:,idx))] ;
%         else
              init = ceil(prim_detections);
%         end
        
        %**
        preditected_roi = run_predictor(cur_img, fol_img, init) ;
        
        num_det_obj_filt = size(preditected_roi,2) ;
        if ~(num_det_obj_filt==0)
            for ii=1:num_det_obj_filt
                trckr_out = preditected_roi(:,ii) ;
                TrDifficult = false(1, numel(num_det_obj_filt)) ;
                output{ii} = tracker_invol(trckr_out, TrDifficult , prim_detections, prim_scores) ;
                final_det{ii,:} = find(output{ii}.detBoxFlags >= 1) ;
            end
            %             disp(i)
            det_final = unique(cell2mat(final_det((~cellfun('isempty',final_det)))));
            for jj=1:size(det_final,1)
                detections(:,jj) = prim_detections(:,det_final(jj)) ;
                scores(:,jj) = prim_scores(det_final(jj)) ;
            end
        end
        if (num_det_obj_filt==0)||  isempty(det_final)
            [scores  ind]= max(prim_scores) ;
            detections = prim_detections(:,ind) ;
        end
        
        %**********************************************************************
        % Find all the objects in the target image
        
        ok = find(strcmp(testImages{i}, testBoxImages)) ;
        gtBoxes = testBoxes(:, ok) ;
        gtDifficult = false(1, numel(ok)) ;
        matches(i) = evalDetections(...
            gtBoxes, gtDifficult, ...
            detections, scores) ;
        
        % Visualize progres
        clf;
        subplot(1,3,[1 2]) ;
        imagesc(im) ; axis equal ; hold on ;
        labels = arrayfun(@(x)sprintf('%d',x),1:size(detections,2),'uniformoutput',0) ;
        sp = fliplr(find(matches(i).detBoxFlags == -1)) ;
        sn = fliplr(find(matches(i).detBoxFlags == +1)) ;
        vl_plotbox(detections(:, sp), 'r', 'linewidth', 1, 'label', labels(sp)) ;
        vl_plotbox(detections(:, sn), 'g', 'linewidth', 2, 'label', labels(sn)) ;
        vl_plotbox(gtBoxes, 'b', 'linewidth', 1) ;
        title(sprintf('Image %d of %d', i, numel(testImages))) ;
        axis off ;
        
        subplot(1,3,3) ;
        vl_pr([matches.labels], [matches.scores], 'IncludeInf', 'false') ; %
        
        % If required, collect top negative features
        if nargout > 1
            overlaps = boxoverlap(gtBoxes, detections) ;
            overlaps(end+1,:) = 0 ;
            overlaps = max(overlaps,[],1) ;
            detections(:, overlaps >= 0.25) = [] ;
            detections = vl_colsubset(detections, 1, 'beginning') ;
            negs{end+1} = extract(hog, hogCellSize, scales, w, detections) ;
        end
        
        % Break here with the debugger
        drawnow ;
        %     end
    end
end

if nargout > 1
    negs = cat(4, negs{:}) ;
end
% figure; vl_roc([matches.labels], [matches.scores])

%**************************************************************************

%     if hard_minning == false
%         num_obj_in_scene = size(fieldnames(storages_trckr),1) ;
%         trckr_out = [storages_trckr.one(i).detections]' ;
%         TrDifficult = false(1, numel(num_obj_in_scene)) ;
%         output = tracker_invol(trckr_out, TrDifficult , detections, scores) ;
%         final_det = find(output.detBoxFlags >= 1) ;
%         if ~(final_det == 0)
%             detections = detections(:,final_det) ;
%             scores = scores(final_det) ;
%         end
%     end
%