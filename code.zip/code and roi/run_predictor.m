%Soroosh Shalileh Master Thesis "Crowd Scene Analysis"
% This Section is Based on Paper :????

function preditected_roi = run_predictor(cur_img, fol_img, init)


preditected_roi = [] ;
temp_prediction = [] ;
num_obj = size(init,2) ;


for ii=1:num_obj
    initstate = init(1:4,ii);   %initial tracker
    img = cur_img ;
    img = double(img(:,:,1));
    %----------------------------------------------------------------
    trparams.init_negnumtrain = 50;%number of trained negative samples
    trparams.init_postrainrad = 4.0;%radical scope of positive samples
    trparams.initstate = initstate;% object position [x y width height]
    trparams.srchwinsz = 20;% size of search window
    % Sometimes, it affects the results.
    %-------------------------
    % classifier parameters
    clfparams.width = trparams.initstate(3);
    clfparams.height= trparams.initstate(4);
    %-------------------------
    % feature parameters
    % number of rectangle from 2 to 4.
    ftrparams.minNumRect = 2;
    ftrparams.maxNumRect = 4;
    %-------------------------
    M = 50;% number of all weaker classifiers, i.e,feature pool
    %-------------------------
    posx.mu = zeros(M,1);% mean of positive features
    negx.mu = zeros(M,1);
    posx.sig= ones(M,1);% variance of positive features
    negx.sig= ones(M,1);
    %-------------------------Learning rate parameter
    lRate = 0.7;
    %-------------------------
    %compute feature template
    [ftr.px,ftr.py,ftr.pw,ftr.ph,ftr.pwt] = HaarFtr(clfparams,ftrparams,M);
    %-------------------------
    %compute sample templates
    posx.sampleImage = sampleImg(img,initstate,trparams.init_postrainrad,0,100000);
    negx.sampleImage = sampleImg(img,initstate,1.5*trparams.srchwinsz,4+trparams.init_postrainrad,50);
    %-----------------------------------
    %--------Feature extraction
    iH = integral(img);%Compute integral image
    posx.feature = getFtrVal(iH,posx.sampleImage,ftr);
    negx.feature = getFtrVal(iH,negx.sampleImage,ftr);
    %--------------------------------------------------
    [posx.mu,posx.sig,negx.mu,negx.sig] = classiferUpdate(posx,negx,posx.mu,posx.sig,negx.mu,negx.sig,lRate);% update distribution parameters
    %-------------------------------------------------
%     num = 1 ;% number of frames -  length(img_dir)
    %--------------------------------------------------------
    x = initstate(1);% x axis at the Top left corner
    y = initstate(2);
    w = initstate(3);% width of the rectangle
    h = initstate(4);% height of the rectangle
%     disp('ii value') %for debuge
%     disp(ii)  %for debuge
    
    %--------------------------------------------------------
    for i = 1:fol_img.Count %num
        %     img = imread(img_dir(i).name);
        img = imread(fol_img.ImageLocation{i}) ;
        imgSr = img;% imgSr is used for showing tracking results.
        img = double(img(:,:,1));
        if ~isempty(initstate)
%             disp('i value in first if') %for debuge
%             disp(i) %for debuge
            detectx.sampleImage = sampleImg(img,initstate,trparams.srchwinsz,0,100000);
            iH = integral(img);%Compute integral image
            detectx.feature = getFtrVal(iH,detectx.sampleImage,ftr);
            %------------------------------------
            r = ratioClassifier(posx,negx,detectx);% compute the classifier for all samples
            clf = sum(r);% linearly combine the ratio classifiers in r to the final classifier
            %-------------------------------------
            [c,index] = max(clf);
            %--------------------------------
            x = detectx.sampleImage.sx(index);
            y = detectx.sampleImage.sy(index);
            w = detectx.sampleImage.sw(index);
            h = detectx.sampleImage.sh(index);
            initstate = [x y w h];
            if ~isempty(initstate)
%                 disp('i value in 2th if') %for debuge
%                 disp(i) %for debuge
                %-------------------------------Show the tracking results
%                 figure(10);
%                 imshow(uint8(imgSr));
%                 rectangle('Position',initstate(1:4),'LineWidth',4,'EdgeColor','y');
%                 hold on;
%                 text(5, 18, strcat('#',num2str(ii)), 'Color','y', 'FontWeight','bold', 'FontSize',15);
%                 set(gca,'position',[0 0 1 1]);
%                 pause(0.00001);
%                 hold off;
                %------------------------------Extract samples
                posx.sampleImage = sampleImg(img,initstate,trparams.init_postrainrad,0,100000);
                negx.sampleImage = sampleImg(img,initstate,1.5*trparams.srchwinsz,4+trparams.init_postrainrad,trparams.init_negnumtrain);
                %--------------------------------------------------Update all the features
                posx.feature = getFtrVal(iH,posx.sampleImage,ftr);
                negx.feature = getFtrVal(iH,negx.sampleImage,ftr);
                %--------------------------------------------------
                [posx.mu,posx.sig,negx.mu,negx.sig] = classiferUpdate(posx,negx,posx.mu,posx.sig,negx.mu,negx.sig,lRate);% update distribution parameters
                %                 temp_prediction_struct{:,i,ii}   = {[x y (x+w) (y+h)]} ;
                temp_prediction(:,i,ii) = [x y (x+w) (y+h)] ;
                
            end
        end
%         disp('end for i') %for debuge
    end
    
    
end

reshaped_temp_prediction = reshape(temp_prediction,4,[]);
preditected_roi = reshaped_temp_prediction(:,any(reshaped_temp_prediction,1));
% preditected_roi = temp_prediction(any(temp_prediction,2),:) ;
end



 
