mex integral.cpp;
mex FtrVal.cpp;