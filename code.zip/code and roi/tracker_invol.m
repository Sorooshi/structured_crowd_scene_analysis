function output = tracker_invol(trckr_out, TrDifficult , detBoxes, detScores, varargin) %
% EVALDETECTIONS
%   OUTPUT = EVALDETECTIONS(TRCKR_OUT, TrDIFFICUTL, DETBOXES, DETSCORES)
%
%   MATCH.DETBOXFLAGS: +1 good, 0 match to difficult/ignored, -1 wrong
%   MATCH.DETBOXTOTr:  map to matched Tr,  NaN if no match
%   MATCH.TRBOXTODET:  map to matched Det, NaN if missed, 0 if difficult, -1 if ignored
%   MATCH.SCORES:      for evaluation (missed boxes have -inf score)
%   MATCH.LABELS:      for evaluation (difficult/ignored boxes are assigned 0 label)
%
%   The first portion fo OUTPUT.SCORES and OUTPUT.LABELS correspond to
%   the DETBOXES, and DETSCORES passed as input. To these, any
%   non-matched tracker thruth bounding box is appended with -INF
%   score.
%
%   The boxes are assumed to be given in the PASCAL format, i.e.  the
%   coordinates are indeces of the top-left, bottom-right pixels, not
%   dimensionless coordinates of the box boundaries.
%
%   The detection scores are NOT used to reorder the detection boxes
%   (these should normally be passed by decreasing score) so the
%   output variables match the order of the input variables.
%

clear output ;
opts.threshold = 0.1 ;
opts.criterion = 'overlap' ;
opts.ignoreDuplicates = true ;
opts.pascalFormat = true ;
opts.display = false ;
opts = vl_argparse(opts, varargin) ;
numTrBoxes  = size(trckr_out, 2) ;
numDetBoxes = size(detBoxes, 2) ;

TrBoxToDet  = NaN * ones(1, numTrBoxes) ;
detBoxToTr  = NaN * zeros(1, numDetBoxes) ;
detBoxFlags = - ones(1,numDetBoxes) ;

if isempty(trckr_out)
  output.detBoxFlags = detBoxFlags ;
  output.detBoxToTr  = detBoxToTr ;
  output.trBoxToDet  = [] ;
  output.scores      = detScores ;
  output.labels      = -ones(1,size(detBoxes,2)) ;
  return ;
end

% match detected boxes to Tr boxes based on the selected criterion
switch lower(opts.criterion)
  case 'overlap'
    criterion = boxoverlap(trckr_out, detBoxes, 'pascalFormat', opts.pascalFormat) ;
  case 'inclusion'
    criterion = boxinclusion(trckr_out, detBoxes, 'pascalFormat', opts.pascalFormat) ;
  otherwise
    error('Unknown criterion %s.',  opts.criterion) ;
end
[criterion, allDetBoxToTr] = max(criterion', [], 2) ;

% prematch detected boxes to difficult Tr boxes and remove them from
% the evaluation
selDiff = find((criterion > opts.threshold) & TrDifficult(1,allDetBoxToTr)') ;
detBoxFlags(selDiff) = 0 ;
detBoxToTr(selDiff) = allDetBoxToTr(selDiff) ;
TrBoxToDet(TrDifficult) = 0 ;

% match the remaining detected boxes to the non-difficult Tr boxes
selDetOk = find(criterion > opts.threshold) ;

nMiss = sum(~TrDifficult) ;
for oki = 1:length(selDetOk)
  % if all Tr boxes have been assigned stop
  if nMiss == 0 & ~opts.ignoreDuplicates, break ; end

  dei = selDetOk(oki) ;
  Tri = allDetBoxToTr(dei) ;
  
  % match the Tr box to the detection only if the Tr box
  % is still unassigned (first detection)
  if isnan(TrBoxToDet(Tri))
    TrBoxToDet(Tri)  = dei ;
    detBoxToTr(dei)  = Tri ;
    detBoxFlags(dei) = +1 ;
    nMiss = nMiss - 1 ;

    detBoxToTr(dei)  = Tri ;
    detBoxFlags(dei) = +1 ;
  elseif opts.ignoreDuplicates
    % match the detection to the Tr box in any case
    % if duplicates are ignoreed
    detBoxToTr(dei)  = Tri ;
    detBoxFlags(dei) = 0 ;
  end

end

% calculate equivalent (scores, labels) pair
selM   = find(detBoxFlags == +1) ; % match
selDM  = find(detBoxFlags == -1) ; % don't match
selDF  = find(detBoxFlags ==  0) ; % difficult or ignored

scores = [detScores, -inf * ones(1,nMiss)] ;
labels = [ones(size(detScores)), ones(1,nMiss)] ;
labels(selDM) = -1 ;
labels(selDF) = 0 ;

output.detBoxFlags = detBoxFlags ;
output.detBoxToTr = detBoxToTr ;
output.TrBoxToDet = TrBoxToDet ;
output.scores = scores ;
output.labels = labels ;

if opts.display
  hold on ;
  vl_plotbox(TrBoxes, 'b', 'linewidth', 2) ;
  vl_plotbox(detBoxes(:, detBoxFlags == +1), 'g') ;
  vl_plotbox(detBoxes(:, detBoxFlags ==  0), 'y') ;
  vl_plotbox(detBoxes(:, detBoxFlags == -1), 'r') ;
end
